import requests
from bs4 import BeautifulSoup
import smtplib

#in side the URL type the link of the product you want to keep track
 URL= "......"

# inside the User_Agent enter your device user agent id 
headers= {
  "User_Agent":'.....'
}

def check_price():
  page= requests.get(URL,headers=headers)
  soup= BeautifulSoup(page.content,'html.parser')
  title=soup.find(id="productTitle").get_text()
  price=soup.find(id="priceblock").get_text()
  converted_price= float(price [0:6])
  if (converted_price<#price of your product):
    send_mail()
    
    print(converted_price)
    print(title.strip())
    
    if(converted_price<#price of your product):
      send_mail()
      
      
def send_mail():
  
  server= smtplib.STMP('stmp.gmail.com',587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login#('#enter your email id','#enter your email password')
  
  subject= 'price fell down!'
  body= #paste the link of the product mentioned above'....'
  
  msg= f"{subject}\n\n{body}"
  server.sendmail(
   # 'enter the same email id mentioned above',
   #'enter the email id you want to send the tracking message',
     msg 
     )
  print('HEY EMAIL HAS BEEN SENT!')
  server.quit()

check_price()
  